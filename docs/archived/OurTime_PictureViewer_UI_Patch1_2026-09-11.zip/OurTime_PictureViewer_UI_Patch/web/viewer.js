// Browsing order is an immutable list of IDs from the current collection.
// UI redesign: lightweight viewer toolbar, persistent face-label preferences,
// adaptive photo metadata strip. 2026-09-11.

const VIEWER_PREFS_KEY='ourtime.viewer.preferences.v2';
const DEFAULT_FACE_STYLE={
  fontSize:13,
  fontFamily:'serif',
  textColor:'#f6f1e6',
  backgroundColor:'#141812',
  backgroundOpacity:.38,
  radius:4,
  paddingX:7,
  paddingY:5,
  shadow:true
};
function readViewerPrefs(){
  try{
    const raw=localStorage.getItem(VIEWER_PREFS_KEY);
    return raw?JSON.parse(raw):{};
  }catch(e){return {};}
}
const storedViewerPrefs=readViewerPrefs();
const viewer={
  ids:[],index:0,target:0,offset:0,total:0,context:null,generation:0,busy:false,
  timer:null,playing:false,scale:1,fit:true,loader:null,drafts:new Map(),window:200,
  faceNames:storedViewerPrefs.faceNames!==false,
  faceAlias:storedViewerPrefs.faceAlias===true,
  faceVertical:storedViewerPrefs.faceVertical!==false,
  faceStyle:{...DEFAULT_FACE_STYLE,...(storedViewerPrefs.faceStyle||{})}
};
function saveViewerPrefs(){
  try{
    localStorage.setItem(VIEWER_PREFS_KEY,JSON.stringify({
      faceNames:viewer.faceNames!==false,
      faceAlias:viewer.faceAlias===true,
      faceVertical:viewer.faceVertical!==false,
      faceStyle:viewer.faceStyle,
      slideDelay:Number($('#slide-delay')?.value||storedViewerPrefs.slideDelay||5)
    }));
  }catch(e){}
}
function injectViewerOverrideCss(){
  if(document.querySelector('link[data-viewer-overrides]'))return;
  const link=document.createElement('link');
  link.rel='stylesheet';
  link.href='/viewer-overrides.css';
  link.dataset.viewerOverrides='true';
  document.head.appendChild(link);
}
injectViewerOverrideCss();

const iconSvg={
  minus:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h12"/></svg>',
  plus:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6v12M6 12h12"/></svg>',
  fit:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/></svg>',
  actual:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8v8H8z"/></svg>',
  person:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20v-1.5a7 7 0 0 1 14 0V20"/></svg>',
  alias:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12 12 4h6l2 2v6l-8 8-8-8Z"/><circle cx="16.5" cy="7.5" r="1"/></svg>',
  horizontal:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M5 12h10M5 17h14"/></svg>',
  vertical:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5v14M12 5v10M17 5v14"/></svg>',
  style:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19 10.5 5h3L19 19M7 14h10"/><circle cx="18.5" cy="6" r="2"/></svg>',
  info:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/></svg>',
  play:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 7 8 5-8 5V7Z"/></svg>',
  pause:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 7v10M15 7v10"/></svg>',
  locate:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg>'
};
function setToolIcon(selector,svg,label){
  const el=$(selector); if(!el)return;
  el.innerHTML=svg;
  el.title=label;
  el.setAttribute('aria-label',label);
}
function buildViewerToolbar(){
  const tools=document.querySelector('.viewer-tools');
  if(!tools||tools.dataset.redesigned)return;
  tools.dataset.redesigned='true';

  const zoomGroup=document.createElement('div');zoomGroup.className='viewer-tool-group viewer-tool-zoom';
  const peopleGroup=document.createElement('div');peopleGroup.className='viewer-tool-group viewer-tool-people';
  const actionGroup=document.createElement('div');actionGroup.className='viewer-tool-group viewer-tool-actions';

  ['#zoom-out','#zoom-fit','#zoom-level','#zoom-actual','#zoom-in'].forEach(sel=>{const el=$(sel);if(el)zoomGroup.appendChild(el);});
  ['#toggle-face-names','#toggle-face-alias','#toggle-face-dir'].forEach(sel=>{const el=$(sel);if(el)peopleGroup.appendChild(el);});

  const styleBtn=document.createElement('button');
  styleBtn.type='button';styleBtn.id='face-style-button';styleBtn.setAttribute('aria-expanded','false');
  styleBtn.innerHTML=iconSvg.style;styleBtn.title='人名标签样式';styleBtn.setAttribute('aria-label','人名标签样式');
  peopleGroup.appendChild(styleBtn);

  ['#viewer-info','#viewer-play','#slide-delay','#reveal-button'].forEach(sel=>{const el=$(sel);if(el)actionGroup.appendChild(el);});
  tools.replaceChildren(zoomGroup,peopleGroup,actionGroup);

  setToolIcon('#zoom-out',iconSvg.minus,'缩小');
  setToolIcon('#zoom-fit',iconSvg.fit,'适应窗口');
  setToolIcon('#zoom-actual',iconSvg.actual,'原尺寸 1:1');
  setToolIcon('#zoom-in',iconSvg.plus,'放大');
  setToolIcon('#toggle-face-names',iconSvg.person,'显示/隐藏人名');
  setToolIcon('#toggle-face-alias',iconSvg.alias,'显示/隐藏别名');
  setToolIcon('#viewer-info',iconSvg.info,'详细资料');
  setToolIcon('#viewer-play',iconSvg.play,'播放幻灯片');
  setToolIcon('#reveal-button',iconSvg.locate,'在资源管理器中定位');

  const delay=$('#slide-delay');
  if(delay){
    const saved=Number(storedViewerPrefs.slideDelay);
    if([3,5,10].includes(saved))delay.value=String(saved);
    delay.title='幻灯片切换间隔';
  }
  buildFaceStylePopover();
}
function buildFaceStylePopover(){
  if($('#face-style-popover'))return;
  const body=document.querySelector('.viewer-body'); if(!body)return;
  const pop=document.createElement('section');
  pop.id='face-style-popover';pop.className='face-style-popover';pop.hidden=true;
  pop.setAttribute('aria-label','人名标签样式设置');
  pop.innerHTML=`
    <div class="face-style-head"><b>人名标签</b><button type="button" id="face-style-close" aria-label="关闭">×</button></div>
    <div class="face-style-preview"><span id="face-style-preview-label">关恺欣</span></div>
    <label>字号 <output id="face-font-size-value"></output><input id="face-font-size" type="range" min="10" max="22" step="1"></label>
    <label>字体 <select id="face-font-family"><option value="sans">黑体 / 无衬线</option><option value="serif">宋体 / 衬线</option><option value="kai">楷体</option></select></label>
    <div class="face-style-colors"><label>文字<input id="face-text-color" type="color"></label><label>底色<input id="face-bg-color" type="color"></label></div>
    <label>底色透明度 <output id="face-bg-opacity-value"></output><input id="face-bg-opacity" type="range" min="0" max="90" step="1"></label>
    <label>圆角 <select id="face-radius"><option value="0">直角</option><option value="4">微圆角</option><option value="10">圆角</option><option value="999">胶囊</option></select></label>
    <label class="face-shadow-row"><input id="face-shadow" type="checkbox"> 文字阴影（亮背景更清楚）</label>
    <button type="button" id="face-style-reset" class="face-style-reset">恢复默认</button>`;
  body.appendChild(pop);

  const bind=(id,event,fn)=>{const el=$(id);if(el)el.addEventListener(event,fn);};
  bind('#face-style-close','click',()=>toggleFaceStylePopover(false));
  bind('#face-font-size','input',e=>updateFaceStyle({fontSize:Number(e.target.value)}));
  bind('#face-font-family','change',e=>updateFaceStyle({fontFamily:e.target.value}));
  bind('#face-text-color','input',e=>updateFaceStyle({textColor:e.target.value}));
  bind('#face-bg-color','input',e=>updateFaceStyle({backgroundColor:e.target.value}));
  bind('#face-bg-opacity','input',e=>updateFaceStyle({backgroundOpacity:Number(e.target.value)/100}));
  bind('#face-radius','change',e=>updateFaceStyle({radius:Number(e.target.value)}));
  bind('#face-shadow','change',e=>updateFaceStyle({shadow:e.target.checked}));
  bind('#face-style-reset','click',()=>{viewer.faceStyle={...DEFAULT_FACE_STYLE};applyFaceStyle();saveViewerPrefs();if(state.detail)renderFaceNames(state.detail);});
  applyFaceStyle();
}
function faceFontStack(kind){
  if(kind==='sans')return '"Microsoft YaHei UI","Microsoft YaHei","PingFang SC","Noto Sans CJK SC",sans-serif';
  if(kind==='kai')return '"KaiTi","STKaiti","Kaiti SC",serif';
  return '"Iowan Old Style","Palatino Linotype","STSong","SimSun",serif';
}
function applyFaceStyle(){
  const root=$('#detail-dialog')||document.documentElement;
  const s=viewer.faceStyle||DEFAULT_FACE_STYLE;
  root.style.setProperty('--face-font-size',`${s.fontSize}px`);
  root.style.setProperty('--face-font-family',faceFontStack(s.fontFamily));
  root.style.setProperty('--face-text-color',s.textColor);
  root.style.setProperty('--face-bg-color',s.backgroundColor);
  root.style.setProperty('--face-bg-opacity',String(s.backgroundOpacity));
  root.style.setProperty('--face-bg-rgba',hexToRgba(s.backgroundColor,s.backgroundOpacity));
  root.style.setProperty('--face-radius',s.radius>=999?'999px':`${s.radius}px`);
  root.style.setProperty('--face-padding-x',`${s.paddingX}px`);
  root.style.setProperty('--face-padding-y',`${s.paddingY}px`);
  root.style.setProperty('--face-shadow',s.shadow?'0 1px 10px rgba(0,0,0,.65)':'none');

  const fontSize=$('#face-font-size'),family=$('#face-font-family'),text=$('#face-text-color'),bg=$('#face-bg-color'),op=$('#face-bg-opacity'),radius=$('#face-radius'),shadow=$('#face-shadow');
  if(fontSize)fontSize.value=String(s.fontSize);
  if(family)family.value=s.fontFamily;
  if(text)text.value=s.textColor;
  if(bg)bg.value=s.backgroundColor;
  if(op)op.value=String(Math.round(s.backgroundOpacity*100));
  if(radius)radius.value=String(s.radius);
  if(shadow)shadow.checked=!!s.shadow;
  if($('#face-font-size-value'))$('#face-font-size-value').textContent=`${s.fontSize}px`;
  if($('#face-bg-opacity-value'))$('#face-bg-opacity-value').textContent=`${Math.round(s.backgroundOpacity*100)}%`;
  const preview=$('#face-style-preview-label');
  if(preview){
    preview.style.fontSize=`${s.fontSize}px`;preview.style.fontFamily=faceFontStack(s.fontFamily);preview.style.color=s.textColor;
    preview.style.backgroundColor=hexToRgba(s.backgroundColor,s.backgroundOpacity);preview.style.borderRadius=s.radius>=999?'999px':`${s.radius}px`;preview.style.textShadow=s.shadow?'0 1px 10px rgba(0,0,0,.65)':'none';
  }
}
function hexToRgba(hex,alpha){
  const h=String(hex||'#000000').replace('#','');
  const full=h.length===3?h.split('').map(x=>x+x).join(''):h.padEnd(6,'0').slice(0,6);
  const n=parseInt(full,16);if(!Number.isFinite(n))return `rgba(0,0,0,${alpha})`;
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${alpha})`;
}
function updateFaceStyle(patch){
  viewer.faceStyle={...viewer.faceStyle,...patch};applyFaceStyle();saveViewerPrefs();
  if(state.detail)requestAnimationFrame(()=>renderFaceNames(state.detail));
}
function toggleFaceStylePopover(force){
  const pop=$('#face-style-popover'),btn=$('#face-style-button');if(!pop)return;
  const open=force==null?pop.hidden:!!force;
  pop.hidden=!open;if(btn)btn.setAttribute('aria-expanded',String(open));
  if(open)applyFaceStyle();
}
function updateToolVisuals(){
  const dir=$('#toggle-face-dir');
  if(dir){
    const vertical=viewer.faceVertical!==false;
    dir.innerHTML=vertical?iconSvg.vertical:iconSvg.horizontal;
    const next=vertical?'切换为横排':'切换为竖排';
    dir.title=next;dir.setAttribute('aria-label',next);
  }
  const play=$('#viewer-play');
  if(play){
    play.innerHTML=viewer.playing?iconSvg.pause:iconSvg.play;
    const label=viewer.playing?'暂停幻灯片':'播放幻灯片';play.title=label;play.setAttribute('aria-label',label);
  }
}

function currentBrowseContext(){return {q:state.q,filter:state.view,person:state.person,directory:state.directory,sort:state.sort,max_id:state.maxId};}
function contextLabel(c){const person=state.people.find(p=>String(p.id)===c.person);const filter=c.filter||'';const heading=c.person?(person?.name||'人物 '+c.person):filter.startsWith('year:')?(filter.slice(5)==='unknown'?'时间未记录':filter.slice(5)+' 年'):filter.startsWith('group:')?(filter.slice(6)==='10plus'?'10人及以上':Number(filter.slice(6))+'人合影'):filter.startsWith('place:')?(filter.slice(6)==='unknown'?'地点未记录':filter.slice(6)):titles[filter]?.[0]||'照片';return [heading,c.directory?basename(c.directory):'',c.q?'搜索：'+c.q:''].filter(Boolean).join(' · ');}
function viewerMessage(text){$('#viewer-message').textContent=text;}
function stopSlides(){viewer.playing=false;clearTimeout(viewer.timer);viewer.timer=null;syncViewerTools();}
function pressTool(id, on){const el=$(id); if(!el)return; el.setAttribute('aria-pressed', String(!!on));}
function syncViewerTools(){
 pressTool('#toggle-face-names', viewer.faceNames!==false);
 pressTool('#toggle-face-alias', viewer.faceAlias===true);
 pressTool('#toggle-face-dir', viewer.faceVertical!==false);
 pressTool('#viewer-info', !$('#detail-dialog').classList.contains('hide-info'));
 pressTool('#viewer-play', viewer.playing);
 const aliasBtn=$('#toggle-face-alias'); if(aliasBtn) aliasBtn.disabled=viewer.faceNames===false;
 const dirBtn=$('#toggle-face-dir'); if(dirBtn) dirBtn.disabled=viewer.faceNames===false;
 const styleBtn=$('#face-style-button');if(styleBtn)styleBtn.disabled=viewer.faceNames===false;
 updateToolVisuals();
}
function scheduleSlide(){clearTimeout(viewer.timer);viewer.timer=setTimeout(async()=>{try {await movePhoto(1,true);}catch(e){viewerMessage(e.message);stopSlides();}},Number($('#slide-delay').value)*1000);}
function updatePosition(){
 const absolute=Number.isFinite(viewer.absolute)?viewer.absolute:(viewer.offset||0)+(viewer.index||0);
 $('#viewer-position').textContent=`${fmt(absolute+1)} / ${fmt(viewer.total||viewer.ids.length)}`;
 $('#viewer-prev').disabled=absolute<=0;$('#viewer-next').disabled=absolute>=(viewer.total||viewer.ids.length)-1;
 $('#viewer-context').textContent=contextLabel(viewer.context||{});
}
function updateZoom(reset=false){
 const img=$('#detail-img'),area=$('#image-viewport'),mat=$('#photo-mat');if(!img.naturalWidth)return;
 const signature=$('#photo-signature');
 const signatureHeight=signature&&!signature.hidden?Number(getComputedStyle(document.documentElement).getPropertyValue('--viewer-signature-h').replace('px',''))||68:0;
 if(viewer.fit){
  const width=Math.max(40, area.clientWidth);
  const height=Math.max(40, area.clientHeight-signatureHeight);
  viewer.scale=Math.max(.01, Math.min(width/img.naturalWidth, height/img.naturalHeight));
 }
 const w=Math.max(1,Math.round(img.naturalWidth*viewer.scale));
 const h=Math.max(1,Math.round(img.naturalHeight*viewer.scale));
 mat.classList.toggle('compact-signature',w<560);
 area.classList.toggle('zoomed', !viewer.fit);
 mat.style.width=w+'px';
 img.style.width=w+'px';
 img.style.height=h+'px';
 $('#zoom-level').textContent=Math.round(viewer.scale*100)+'%';
 if(reset){area.scrollTop=0;area.scrollLeft=0;}
 if(state.detail && viewer.faceNames!==false) requestAnimationFrame(()=>renderFaceNames(state.detail));
}
function renderSignature(a,file){
 const signature=$('#photo-signature');if(!signature)return;
 const tags=a.metadata?.ExifTool||{};
 const tag=name=>Object.entries(tags).find(([key])=>key.split(':').at(-1)===name)?.[1];
 const clean=value=>String(value||'').replace(/\0/g,'').trim();
 const number=name=>{const raw=tag(name);const n=Number(raw);return Number.isFinite(n)&&n>0?n:null;};
 const make=clean(tag('Make')),model=clean(tag('Model'));
 const camera=model?(make&&model.toLowerCase().startsWith(make.toLowerCase())?model:[make,model].filter(Boolean).join(' ')):clean(a.camera);
 const source=a.effective_source||'';
 const timeKind=source.includes('修改')?'文件时间参考':source.includes('推测')?'推测时间':source==='人工确认'?'补录时间':'拍摄时间';
 const rawDate=clean(a.effective_date);
 const shownDate=/^\d{4}-\d\d-\d\dT/.test(rawDate)?rawDate.slice(0,16).replaceAll('-','.').replace('T','  '):rawDate;
 const place=prettyPlace(a.effective_place)||'';
 const focal=number('FocalLengthIn35mmFormat')||number('FocalLength');
 const aperture=number('FNumber'),shutter=number('ExposureTime'),iso=number('ISO');
 const exposure=[];
 if(focal)exposure.push(`${Number(focal.toFixed(1))}mm`);
 if(aperture)exposure.push(`ƒ/${Number(aperture.toFixed(1))}`);
 if(shutter)exposure.push(shutter<1?`1/${Math.round(1/shutter)}s`:`${Number(shutter.toFixed(2))}s`);
 if(iso)exposure.push(`ISO ${Math.round(iso)}`);
 const size=Number(file?.size);
 const fileSize=Number.isFinite(size)&&size>0?(size>=1024*1024?(size/1024/1024).toFixed(1)+' MB':(size/1024).toFixed(0)+' KB'):'';
 const dimensions=(Number(a.width)>0&&Number(a.height)>0)?`${a.width} × ${a.height}`:'';
 const format=clean(a.format)||clean(file?.path?.split('.').pop()?.toUpperCase());
 const basics=[dimensions,format,fileSize].filter(Boolean);
 const filename=file?.path?basename(file.path):'';
 const hasMemory=Boolean(shownDate||place);
 const hasCapture=Boolean(camera||exposure.length);

 let mainHtml='';
 if(hasMemory){
  mainHtml=`<div class="signature-primary">${shownDate?`<strong>${esc(shownDate)}</strong><small>${esc(timeKind)}</small>`:''}${place?`<span class="signature-place">${esc(place)}</span>`:''}</div>`;
 }else if(hasCapture){
  mainHtml=`<div class="signature-primary"><strong>${esc(camera||'拍摄信息')}</strong>${exposure.length?`<span class="signature-inline">${exposure.map(esc).join(' · ')}</span>`:''}</div>`;
 }else{
  mainHtml=`<div class="signature-primary"><strong>${esc(filename||'图片')}</strong><small>基础文件信息</small></div>`;
 }
 const captureBits=[];
 if(hasMemory&&camera)captureBits.push(camera);
 if(hasMemory&&exposure.length)captureBits.push(...exposure);
 if(!hasMemory&&hasCapture&&basics.length)captureBits.push(...basics);
 if(!hasMemory&&!hasCapture)captureBits.push(...basics);
 const fallbackBits=(hasMemory||hasCapture)?basics:[];

 signature.innerHTML=`
  <div class="signature-v2">
   <span class="signature-seal-v2" aria-hidden="true">拾</span>
   ${mainHtml}
   <div class="signature-secondary">${captureBits.length?captureBits.map(v=>`<span>${esc(v)}</span>`).join(''):''}</div>
   ${fallbackBits.length?`<div class="signature-file">${fallbackBits.map(esc).join(' · ')}</div>`:''}
  </div>`;
 signature.hidden=false;
 signature.title=[shownDate&&`${timeKind}：${rawDate}`,place&&`地点：${place}`,camera&&`设备：${camera}`,exposure.join(' · '),basics.join(' · ')].filter(Boolean).join('\n');
}
function namedFaces(photo){return (photo&&photo.faces||[]).filter(f=>f.name&&!f.ignored);}
function visibleFaces(photo){return (photo&&photo.faces||[]).filter(f=>!f.ignored);}
function viewerImageSrc(photo, file, id){
 const w=Number(photo&&photo.width)||0, h=Number(photo&&photo.height)||0;
 const format=String(photo&&photo.format||'').toUpperCase();
 const path=String(file&&file.path||'');
 const ext=(path.split('.').pop()||'').toLowerCase();
 const heavyExt=['heic','heif','dng','arw','cr2','nef','raf','rw2','orf','tif','tiff'];
 const browserOk=['jpg','jpeg','png','gif','webp','bmp'];
 const tooBig=(w&&h&&(w*h>12000000 || Math.max(w,h)>4000)) || Number(file&&file.size)>12*1024*1024;
 if(!photo||!photo.in_library) return '/api/thumb/'+id+'?v='+state.thumbRevision;
 if(tooBig || heavyExt.includes(ext) || ['HEIF','TIFF','MPO'].includes(format) || (ext && !browserOk.includes(ext))){
  return '/api/preview/'+id+'?v='+state.thumbRevision;
 }
 return '/api/original/'+id;
}
function faceBox(face){
 let box=face.bbox; if(typeof box==='string'){try{box=JSON.parse(box);}catch(e){box=null;}}
 if(!Array.isArray(box)||box.length<4)return null;
 const [x1,y1,x2,y2,w,h]=box.map(Number);
 if(![x1,y1,x2,y2].every(Number.isFinite))return null;
 return {x1,y1,x2,y2,w:w||0,h:h||0,cx:(x1+x2)/2,cy:(y1+y2)/2,width:Math.max(1,x2-x1),height:Math.max(1,y2-y1)};
}
function faceLabelText(face, alias){
  if(face.name) return alias&&face.alias?(face.name+' / '+face.alias):face.name;
  return '命名';
}
function rectsOverlap(a,b,gap=6){
  return a.x<b.x+b.w+gap && a.x+a.w+gap>b.x && a.y<b.y+b.h+gap && a.y+a.h+gap>b.y;
}
function clampFaceLabel(rect, layerW, layerH, pad=6){
  rect.x=Math.min(Math.max(pad, rect.x), Math.max(pad, layerW-rect.w-pad));
  rect.y=Math.min(Math.max(pad, rect.y), Math.max(pad, layerH-rect.h-pad));
  return rect;
}
function layoutFaceNameButtons(layer, faces, alias){
  const img=$('#detail-img');
  if(!img||!img.naturalWidth||!layer.clientWidth)return;
  const layerW=layer.clientWidth, layerH=layer.clientHeight;
  const imgRect=img.getBoundingClientRect();
  const layerRect=layer.getBoundingClientRect();
  const ox=imgRect.left-layerRect.left;
  const oy=imgRect.top-layerRect.top;
  const imgW=imgRect.width, imgH=imgRect.height;
  const items=[];
  faces.forEach(face=>{
    const box=faceBox(face); if(!box||!box.w||!box.h)return;
    const fx=ox+box.x1/box.w*imgW;
    const fy=oy+box.y1/box.h*imgH;
    const fw=box.width/box.w*imgW;
    const fh=box.height/box.h*imgH;
    items.push({face, named:Boolean(face.name), label:faceLabelText(face,alias), fx, fy, fw, fh, cx:fx+fw/2, cy:fy+fh/2});
  });
  items.sort((a,b)=>a.cx-b.cx||a.cy-b.cy);
  layer.innerHTML=items.map(it=>'<button type="button" class="face-name'+(it.named?'':' unnamed')+'" data-face-person="'+it.face.person_id+'">'+esc(it.label)+'</button>').join('');
  const buttons=[...layer.querySelectorAll('.face-name')];
  const vertical=viewer.faceVertical!==false;
  const placed=[];
  const gap=4;
  const avgCx=items.reduce((s,it)=>s+it.cx,0)/Math.max(1,items.length);
  const side = avgCx < (ox + imgW/2) ? 'right' : 'left';
  buttons.forEach((btn,i)=>{
    const it=items[i];
    const w=Math.max(18, btn.offsetWidth);
    const h=Math.max(18, btn.offsetHeight);
    let x,y;
    if(vertical){
      const tuck=Math.min(8, Math.round(w*0.28));
      x = side==='left' ? it.fx - w + tuck : it.fx + it.fw - tuck;
      y = it.fy + it.fh*0.16;
    }else{
      x = it.cx - w/2;
      y = it.fy + it.fh*0.10;
    }
    const rect=clampFaceLabel({x,y,w,h,side,btn}, layerW, layerH);
    placed.push(rect);
    btn.classList.add(side);
  });
  placed.sort((a,b)=> (a.x-b.x) || (a.y-b.y));
  for(let i=1;i<placed.length;i++){
    const prev=placed[i-1], cur=placed[i];
    if(!rectsOverlap(prev,cur,gap)) continue;
    cur.y = Math.max(cur.y, prev.y + prev.h + gap);
    clampFaceLabel(cur, layerW, layerH);
  }
  placed.forEach(rect=>{
    rect.btn.style.left=Math.round(rect.x)+'px';
    rect.btn.style.top=Math.round(rect.y)+'px';
  });
}
function renderFaceNames(photo){
 const layer=$('#face-name-layer'); if(!layer)return;
 const show=viewer.faceNames!==false;
 const alias=viewer.faceAlias===true;
 const vertical=viewer.faceVertical!==false;
 layer.hidden=!show;
 layer.classList.toggle('horizontal',!vertical);
  if(!show){layer.innerHTML='';syncViewerTools();return;}
  const faces=visibleFaces(photo);
  if(!$('#detail-img')?.naturalWidth || !layer.clientWidth){
    layer.innerHTML='';
    requestAnimationFrame(()=>{ if(state.detail===photo) layoutFaceNameButtons(layer, faces, alias); });
  }else layoutFaceNameButtons(layer, faces, alias);
  syncViewerTools();
}
function zoomTo(scale){viewer.fit=false;viewer.scale=Math.max(.05,Math.min(4,scale));updateZoom();}
async function displayPhoto(id){
 if(viewer.loader){viewer.loader.onload=null;viewer.loader.onerror=null;viewer.loader.src='';}
 if(!await renderPhoto(id))return false;
 const root=(viewer.context?.directory||'').replace(/[\/]+$/,'').toLowerCase();
 const files=[...state.detail.files].sort((a,b)=>a.excluded-b.excluded||b.exists_now-a.exists_now||a.id-b.id);
 const scoped=files.find(f=>!root||f.path.toLowerCase().startsWith(root+String.fromCharCode(92))||f.path.toLowerCase()===root);
 renderSignature(state.detail,scoped||files[0]);
 if(scoped)$('#detail-name').textContent=basename(scoped.path);
 $('#detail-dialog').dataset.photoId=String(id);
 const draft=viewer.drafts.get(id);if(draft)for(const [key,value] of Object.entries(draft))$(key).value=value;
 const file=scoped||files[0];
 const src=viewerImageSrc(state.detail, file, id);
 const current=($('#detail-img').getAttribute('src')||'');
 const applySrc=(url)=>{
  if(!$('#detail-dialog').open||state.detail?.id!==id)return;
  viewer.fit=true;
  $('#detail-img').src=url;
  updateZoom(true);
  renderFaceNames(state.detail);
  viewerMessage(draft?'这张照片有尚未保存的补录，已暂存在本页。':!state.detail.in_library?'已排除 · 缓存已清理':'');
 };
 updatePosition();
 if(current===src || current.endsWith(src)){applySrc(current);return true;}
 const image=new Image();viewer.loader=image;
 await new Promise(resolve=>{
  image.onload=()=>{applySrc(image.src);resolve();};
  image.onerror=()=>{
   if(!src.includes('/api/preview/')){
    const fallback=new Image(); viewer.loader=fallback;
    fallback.onload=()=>{applySrc(fallback.src);resolve();};
    fallback.onerror=()=>{viewerMessage('这张图暂时无法显示');resolve();};
    fallback.src='/api/preview/'+id+'?v='+state.thumbRevision;
    return;
   }
   viewerMessage('这张图暂时无法显示');
   resolve();
  };
  image.src=src;
 });
 return true;
}
async function openPhoto(id,context=null){
 if(!$('#detail-dialog').open)viewer.returnScroll=scrollY;
 stopSlides();
 const alreadyOpen=$('#detail-dialog').open;
 const generation=++viewer.generation;
 viewer.goal=null; viewer.queued=null;
 if(!alreadyOpen){$('#detail-dialog').classList.add('hide-info');syncViewerTools();}
 const nextContext=context||currentBrowseContext();
 const sameContext=viewer.context && JSON.stringify(viewer.context)===JSON.stringify(nextContext);
 if(context || !sameContext || !viewer.ids.includes(id)){
  viewer.context=nextContext;viewer.ids=[];
  const params=new URLSearchParams({...viewer.context,sequence:true,limit:String(viewer.window),around:String(id)});
  const result=await api('/api/photos?'+params);
  if(generation!==viewer.generation)return;
  if(result.missing){viewerMessage('当前范围已变化，请刷新照片列表后再打开。');return;}
  viewer.ids=result.ids||[]; viewer.offset=result.offset||0; viewer.total=result.total||viewer.ids.length; viewer.maxId=result.max_id||viewer.context.max_id;
 }
 if(!viewer.ids.includes(id)){viewerMessage('当前范围已变化，请刷新照片列表后再打开。');return;}
 viewer.index=viewer.target=viewer.ids.indexOf(id);
 viewer.absolute=(viewer.offset||0)+viewer.index;
 viewer.goal=viewer.absolute;
 await displayPhoto(id);
 if(generation===viewer.generation)$('#image-viewport').focus({preventScroll:true});
}
async function ensureViewerWindow(absolute, generation=viewer.generation){
 const total=viewer.total||viewer.ids.length;
 const next=Math.max(0,Math.min(Math.max(total-1,0),absolute));
 const local=next-(viewer.offset||0);
 if(local>=0&&local<viewer.ids.length){
  viewer.absolute=next;
  viewer.target=local;
  return local;
 }
 const ctx={...viewer.context, max_id: viewer.maxId || viewer.context.max_id};
 const params=new URLSearchParams({...ctx,sequence:true,limit:String(viewer.window),offset:String(Math.max(0,next-Math.floor(viewer.window/2)))});
 const result=await api('/api/photos?'+params);
 if(generation!==viewer.generation)return null;
 viewer.ids=result.ids||[]; viewer.offset=result.offset||0; viewer.total=result.total||viewer.ids.length; viewer.maxId=result.max_id||viewer.maxId;
 const idx=Math.max(0, Math.min(viewer.ids.length-1, next-viewer.offset));
 viewer.absolute=next;
 viewer.index=viewer.target=idx;
 return idx;
}
async function movePhoto(delta,automatic=false){
 if(!automatic)stopSlides();
 const total=viewer.total||viewer.ids.length;
 const current=Number.isFinite(viewer.goal)?viewer.goal:(Number.isFinite(viewer.absolute)?viewer.absolute:(viewer.offset||0)+(viewer.target||0));
 const goal=Math.max(0,Math.min(Math.max(total-1,0),current+delta));
 viewer.goal=goal;
 if(goal===current && delta!==0){viewerMessage(goal===0?'已经是当前范围的第一张。':'已经是当前范围的最后一张。');stopSlides();return;}
 if(goal===current){stopSlides();return;}
 await consumeViewerGoal(automatic);
}
async function consumeViewerGoal(automatic=false){
 if(viewer.busy)return;
 viewer.busy=true;
 try{
  while($('#detail-dialog').open){
   const generation=viewer.generation;
   const want=Number.isFinite(viewer.goal)?viewer.goal:(Number.isFinite(viewer.absolute)?viewer.absolute:0);
   const local=await ensureViewerWindow(want, generation);
   if(!$('#detail-dialog').open)return;
   if(generation!==viewer.generation){continue;}
   if(local==null){if(generation!==viewer.generation) continue;return;}
   viewer.absolute=want;
   viewer.index=viewer.target=want-(viewer.offset||0);
   const id=viewer.ids[viewer.index];
   if(id==null){viewerMessage('当前范围已变化，请刷新照片列表后再打开。');return;}
   await displayPhoto(id);
   if(!$('#detail-dialog').open)return;
   if(generation!==viewer.generation) continue;
   if(!Number.isFinite(viewer.goal) || viewer.goal===want){
    if(automatic&&viewer.playing&&generation===viewer.generation&&$('#detail-dialog').open){
     if((viewer.absolute||0)>=(viewer.total||1)-1){stopSlides();viewerMessage('已经播放到当前范围的最后一张。');}
     else scheduleSlide();
    }
    break;
   }
  }
 }catch(e){stopSlides();throw e;}
 finally{
  viewer.busy=false;updatePosition();
  if($('#detail-dialog').open && Number.isFinite(viewer.goal) && viewer.goal!==viewer.absolute){consumeViewerGoal(automatic);}
 }
}

buildViewerToolbar();
applyFaceStyle();
syncViewerTools();

$('#viewer-prev').addEventListener('click',action(()=>movePhoto(-1)));
$('#viewer-next').addEventListener('click',action(()=>movePhoto(1)));
$('#zoom-in').addEventListener('click',()=>zoomTo(viewer.scale*1.25));
$('#zoom-out').addEventListener('click',()=>zoomTo(viewer.scale/1.25));
$('#zoom-fit').addEventListener('click',()=>{viewer.fit=true;updateZoom(true);});
$('#zoom-actual').addEventListener('click',()=>zoomTo(1));
$('#detail-img').addEventListener('load',()=>{updateZoom(true);renderFaceNames(state.detail);});
const faceLayer=$('#face-name-layer');
faceLayer&&faceLayer.addEventListener('pointerdown',e=>{if(e.target.closest('[data-face-person]')){e.stopPropagation();drag=null;}});
faceLayer&&faceLayer.addEventListener('click',e=>{
 const b=e.target.closest('[data-face-person]');
 if(!b)return;
 e.preventDefault();
 e.stopPropagation();
 outsidePhotoDown=false;
 const id=Number(b.dataset.facePerson);
 if(typeof openQuickName==='function') openQuickName(id);
});
$('#toggle-face-names').addEventListener('click',()=>{viewer.faceNames=!viewer.faceNames;saveViewerPrefs();renderFaceNames(state.detail);});
$('#toggle-face-alias').addEventListener('click',()=>{viewer.faceAlias=!viewer.faceAlias;saveViewerPrefs();renderFaceNames(state.detail);});
$('#toggle-face-dir').addEventListener('click',()=>{viewer.faceVertical=!viewer.faceVertical;saveViewerPrefs();renderFaceNames(state.detail);});
$('#face-style-button')?.addEventListener('click',e=>{e.stopPropagation();toggleFaceStylePopover();});
$('#detail-img').addEventListener('dblclick',()=>{if(viewer.fit)zoomTo(1);else{viewer.fit=true;updateZoom(true);}});
function toggleInfo(){$('#detail-dialog').classList.toggle('hide-info');syncViewerTools();}
$('#viewer-info').addEventListener('click',toggleInfo);
$('#close-info').addEventListener('click',toggleInfo);
$('#viewer-play').addEventListener('click',()=>{if(viewer.playing){stopSlides();syncViewerTools();return;}const current=Number.isFinite(viewer.absolute)?viewer.absolute:(viewer.offset||0)+(viewer.target||0);if(current>=(viewer.total||viewer.ids.length)-1){viewerMessage('已经是最后一张，请先返回前面的照片。');return;}viewer.playing=true;syncViewerTools();scheduleSlide();});
$('#slide-delay').addEventListener('change',()=>{saveViewerPrefs();if(viewer.timer)scheduleSlide();});
$('#detail-dialog').addEventListener('close',()=>{stopSlides();toggleFaceStylePopover(false);viewer.generation++;viewer.queued=null;viewer.goal=null;renderPhoto.ticket++;if(viewer.loader){viewer.loader.onload=null;viewer.loader.onerror=null;viewer.loader.src='';}if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});});
$('#detail-dialog').addEventListener('cancel',()=>{viewer.generation++;renderPhoto.ticket++;});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopSlides();});
document.addEventListener('keydown',action(async e=>{
 if(!$('#detail-dialog').open||$$('dialog[open]').at(-1)?.id!=='detail-dialog'||e.target.closest('input,textarea,select,[contenteditable="true"]')||e.ctrlKey||e.altKey||e.metaKey)return;
 const directions={ArrowLeft:-1,ArrowUp:-1,ArrowRight:1,ArrowDown:1};
 if(e.key in directions){e.preventDefault();await movePhoto(directions[e.key]);}
 else if(e.key==='Home'||e.key==='End'){e.preventDefault();const total=viewer.total||viewer.ids.length;const current=Number.isFinite(viewer.absolute)?viewer.absolute:(viewer.offset||0)+(viewer.target||0);await movePhoto(e.key==='Home'?-current:total-1-current);}
}));
let drag=null;const viewport=$('#image-viewport');
viewport.addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('.face-name,button,a,input,textarea,select'))return;drag={x:e.clientX,y:e.clientY,left:viewport.scrollLeft,top:viewport.scrollTop};viewport.setPointerCapture(e.pointerId);});
viewport.addEventListener('pointermove',e=>{if(drag){viewport.scrollLeft=drag.left+drag.x-e.clientX;viewport.scrollTop=drag.top+drag.y-e.clientY;}});
viewport.addEventListener('pointerup',()=>drag=null);viewport.addEventListener('pointercancel',()=>drag=null);
new ResizeObserver(()=>{if($('#detail-dialog').open)updateZoom();}).observe(viewport);
// Remember where a gesture began: dragging a zoomed photo onto the background
// must not close it. Buttons, links and the detail drawer keep their own actions.
let outsidePhotoDown=false;
const keepOpenSelector='#detail-img,button,a,input,textarea,select,.detail-info,.face-name-layer,.face-name,.viewer-tools,.viewer-arrow,.dialog-close,#photo-mat,#photo-signature,.face-style-popover';
$('#detail-dialog').addEventListener('pointerdown',e=>{
 outsidePhotoDown=e.button===0&&!e.target.closest(keepOpenSelector);
});
$('#detail-dialog').addEventListener('click',e=>{
 if(!outsidePhotoDown||e.target.closest(keepOpenSelector))return;
 outsidePhotoDown=false;$('#detail-dialog').close();
});
$('#detail-dialog').addEventListener('close',()=>outsidePhotoDown=false);
$('#detail-form').addEventListener('input',()=>{stopSlides();viewer.drafts.set(state.detail.id,Object.fromEntries(['#edit-date','#edit-precision','#edit-place','#edit-notes'].map(k=>[k,$(k).value])));viewerMessage('补录尚未保存；翻图时会暂存在本页，刷新页面会丢失。');});
$('#sort-order').addEventListener('change',action(async()=>{state.sort=$('#sort-order').value;state.offset=0;await loadPhotos();}));
$('#refresh-photos').addEventListener('click',action(()=>loadPhotos()));
$('#browse-directory').addEventListener('click',action(()=>{state.folderTarget='browse';return openFolder(state.directory);}));
