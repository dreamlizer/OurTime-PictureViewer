// Isolated reproductions using verbatim function fragments from GitHub commit
// 9ba5fe6952642c782d69beeef99fb696a46bb8c7. Not a full app test.
// Sources: web/face-label-model.js; web/viewer.js.
const PLACEHOLDER_NAMES = new Set(['待核对', '命名', '路人']);
const ALIAS_MODES = ['off', 'with', 'only'];
const DIR_MODES = ['auto', 'horizontal', 'vertical'];
function trimText(value){ return String(value == null ? '' : value).trim(); }
function isPlaceholderName(name){ return PLACEHOLDER_NAMES.has(trimText(name)); }
function usableName(name){
  const text = trimText(name);
  return text && !isPlaceholderName(text) ? text : '';
}
function ignoredFlag(value){
  if(value === true || value === 1 || value === '1' || value === 'true') return true;
  if(value === false || value === 0 || value === '0' || value == null || value === '' || value === 'false') return false;
  return false;
}
function aliasModeOf(mode){ return ALIAS_MODES.includes(mode) ? mode : 'off'; }
function resolveFaceLabelState(face, aliasMode){
  const source = face && typeof face === 'object' ? face : {};
  const mode = aliasModeOf(aliasMode);
  const name = usableName(source.name);
  const alias = trimText(source.alias);
  const faceId = Number.isFinite(Number(source.id)) ? Number(source.id) : null;
  const personId = Number.isFinite(Number(source.person_id)) ? Number(source.person_id) : null;
  if(ignoredFlag(source.ignored)){
    return {kind:'passerby', isNamed:false, displayText:'+', accessibleText:'路人', faceId, personId, verticalEligible:false};
  }
  if(!name && !alias){
    return {kind:'pending', isNamed:false, displayText:'+', accessibleText:'待命名', faceId, personId, verticalEligible:false};
  }
  let display = name || alias;
  if(mode === 'only') display = alias || name;
  else if(mode === 'with' && name && alias && name !== alias) display = name + ' / ' + alias;
  else display = name || alias;
  return {kind:'named', isNamed:true, displayText:display, accessibleText:display, faceId, personId, verticalEligible:true};
}
function isLatinDisplayName(text){
  const value = trimText(text);
  if(!value) return false;
  let letters = 0;
  for(const ch of value){
    const code = ch.codePointAt(0);
    const cjk = (code >= 0x3400 && code <= 0x9fff) || (code >= 0xf900 && code <= 0xfaff)
      || (code >= 0x3040 && code <= 0x30ff) || (code >= 0xac00 && code <= 0xd7af);
    if(cjk) return false;
    const latin = (code >= 65 && code <= 90) || (code >= 97 && code <= 122) || (code >= 0x00c0 && code <= 0x024f);
    const punctuation = ch === ' ' || ch === '.' || ch === "'" || ch === '’' || ch === '-';
    if(latin) letters += 1;
    else if(!punctuation) return false;
  }
  return letters > 0;
}
function faceLabelVerticalFor(text, mode){
  const direction = DIR_MODES.includes(mode) ? mode : 'auto';
  if(isLatinDisplayName(text)) return false;
  return direction !== 'horizontal';
}
function faceHasUsableName(face){
  const name=String(face?.name||'').trim();
  const alias=String(face?.alias||'').trim();
  return !face?.ignored&&(Boolean(alias)||(Boolean(name)&&!['待核对','命名','路人'].includes(name)));
}
const state={detail:{faces:[]}};
function photoPeopleSummary(){
  const unique=new Map();
  for(const face of state.detail?.faces||[])if(!unique.has(Number(face.person_id)))unique.set(Number(face.person_id),face);
  const values=[...unique.values()];
  return {
    named:values.filter(faceHasUsableName).length,
    pending:values.filter(face=>!face.ignored&&!faceHasUsableName(face)).length,
    passerby:values.filter(face=>Boolean(face.ignored)).length
  };
}
const results=[];
function result(id, expected, actual){
  results.push({id, expected, actual, status:JSON.stringify(expected)===JSON.stringify(actual)?'PASS':'FAIL'});
}
for(const text of ['Alex', 'A', 'Anne-Marie', 'Émile']){
  result('Latin '+text, false, faceLabelVerticalFor(text,'auto'));
}
const english = resolveFaceLabelState({id:101,person_id:1,name:'Alex',alias:'Alex Chen',ignored:0},'with');
result('English name + alias display', 'Alex / Alex Chen', english.displayText);
result('English name + alias should remain horizontal (auto)', false, faceLabelVerticalFor(english.displayText,'auto'));
result('English exception should remain horizontal (vertical)', false, faceLabelVerticalFor(english.displayText,'vertical'));
result('Chinese should remain vertical',true,faceLabelVerticalFor('陈宁','auto'));
result('Alias only model named', true, resolveFaceLabelState({id:102,person_id:2,name:'',alias:'小宁',ignored:0},'off').isNamed);
result('Placeholder pending', 'pending',resolveFaceLabelState({id:103,person_id:3,name:'待核对',alias:'',ignored:0},'off').kind);
const stringZero={id:104,person_id:4,name:'陈宁',alias:'',ignored:'0'};
state.detail.faces=[stringZero];
result('Model ignored string zero is named','named',resolveFaceLabelState(stringZero,'off').kind);
result('HUD ignored string zero is named',{named:1,pending:0,passerby:0},photoPeopleSummary());
state.detail.faces=[{id:105,name:'陈宁',ignored:0},{id:106,name:'李安',ignored:0}];
result('HUD missing person IDs must not collapse together',2,photoPeopleSummary().named);
const storedViewerPrefs=JSON.parse('null');
const FACE_LABEL_POSITIONS=new Set(['auto','left','right','top','bottom']);
let error=null;
try {
  // Exact expression still used in viewer initialization, despite normalized prefs.
  const value=FACE_LABEL_POSITIONS.has(storedViewerPrefs.faceLabelPosition)?storedViewerPrefs.faceLabelPosition:'auto';
} catch(e) { error=e.name+': '+e.message; }
result('Null preference must not crash viewer initialization',null,error);
const fs=require('fs');
fs.writeFileSync(__dirname+'/logic-results.json',JSON.stringify({scope:'verbatim source fragments; synthetic inputs; no production access',commit:'9ba5fe6952642c782d69beeef99fb696a46bb8c7',results},null,2));
console.log(JSON.stringify(results,null,2));
