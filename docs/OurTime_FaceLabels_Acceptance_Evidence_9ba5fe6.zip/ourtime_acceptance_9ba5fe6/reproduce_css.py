"""Minimal CSS reproductions, not a full app or production-session capture.
Rules below are excerpts from 9ba5fe6 web/face-labels.css and
web/viewer-overrides.css. Test scaffolding only controls presentation.
"""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).parent
shared = r'''
#detail-dialog .face-name:not(.unnamed),
#detail-dialog #face-style-preview-label,
#detail-dialog #local-font-preview-label{
  --face-scale:1;
  position:relative;
  display:inline-grid;
  place-items:center;
  box-sizing:border-box;
  width:max-content;
  height:max-content;
  max-width:none;
  max-height:none;
  border:1px solid transparent;
  border-radius:calc(var(--face-radius) * var(--face-scale));
  background:var(--face-bg-rgba);
  color:var(--face-text-color);
  font-family:var(--face-font-family);
  font-size:calc(var(--face-font-size) * var(--face-scale, 1));
  font-weight:400;
  line-height:1.2;
  letter-spacing:.08em;
  writing-mode:vertical-rl;
  text-orientation:upright;
  white-space:nowrap;
  overflow:visible;
  padding:calc(var(--face-padding-y) * var(--face-scale)) calc(var(--face-padding-x) * var(--face-scale));
  text-shadow:var(--face-shadow);
}
#detail-dialog .face-name:not(.unnamed){position:absolute}
#detail-dialog .face-name.is-horizontal:not(.unnamed),
#detail-dialog #face-style-preview-label.is-horizontal,
#detail-dialog #local-font-preview-label.is-horizontal{
  writing-mode:horizontal-tb;
  text-orientation:mixed;
  letter-spacing:.04em;
}
#detail-dialog[data-face-theme="classic"] .face-name:not(.unnamed),
#detail-dialog[data-face-theme="classic"] #face-style-preview-label,
#detail-dialog[data-face-theme="classic"] #local-font-preview-label{
  background:var(--face-bg-rgba);
  border-color:transparent;
  box-shadow:0 1px 2px rgba(0,0,0,.08);
  backdrop-filter:blur(2px);
  -webkit-backdrop-filter:blur(2px);
}
#detail-dialog[data-face-theme="ivory"] .face-name:not(.unnamed),
#detail-dialog[data-face-theme="tea"] .face-name:not(.unnamed),
#detail-dialog[data-face-theme="ivory"] #face-style-preview-label,
#detail-dialog[data-face-theme="tea"] #face-style-preview-label,
#detail-dialog[data-face-theme="ivory"] #local-font-preview-label,
#detail-dialog[data-face-theme="tea"] #local-font-preview-label{
  --face-plate-corner:calc(8px * var(--face-scale, 1));
  --face-plate-edge:calc(5px * var(--face-scale, 1));
  --face-plate-pad-block:calc(9px * var(--face-scale, 1));
  --face-plate-pad-inline:calc(6px * var(--face-scale, 1));
  --face-plate-slice:210 330 fill;
  isolation:isolate;
  padding:var(--face-plate-pad-block) var(--face-plate-pad-inline);
  border:0;
  border-radius:0;
  background:transparent;
  line-height:1.08;
  letter-spacing:.08em;
  box-shadow:none;
  text-shadow:none;
  backdrop-filter:none;
  -webkit-backdrop-filter:none;
}
#detail-dialog[data-face-theme="tea"] .face-name:not(.unnamed),
#detail-dialog[data-face-theme="tea"] #face-style-preview-label,
#detail-dialog[data-face-theme="tea"] #local-font-preview-label{
  color:#f7ead8;
  font-family:var(--face-font-family);
  --face-plate-slice:170 310 fill;
  --face-label-image:url("/api/face-label-bg/4.png");
}
#detail-dialog[data-face-theme-effective="classic"][data-face-theme="ivory"] .face-name:not(.unnamed),
#detail-dialog[data-face-theme-effective="classic"][data-face-theme="tea"] .face-name:not(.unnamed),
#detail-dialog[data-face-theme-effective="classic"][data-face-theme="ivory"] #face-style-preview-label,
#detail-dialog[data-face-theme-effective="classic"][data-face-theme="tea"] #face-style-preview-label{
  background:var(--face-bg-rgba);
  color:var(--face-text-color);
  font-family:var(--face-font-family);
  border:1px solid transparent;
  border-radius:calc(var(--face-radius) * var(--face-scale));
  box-shadow:0 1px 2px rgba(0,0,0,.08);
}
#detail-dialog[data-face-theme-effective="classic"] .face-name:not(.unnamed)::before,
#detail-dialog[data-face-theme-effective="classic"] #face-style-preview-label::before{content:none}
'''
old_local = r'''
#local-font-preview-label{
  justify-self:center;
  display:grid;
  place-items:center;
  min-width:35px;
  min-height:72px;
  padding:5px;
  border-radius:10px;
  background:rgba(20,24,18,.5);
  color:#f6f1e6;
  font-size:20px;
  line-height:1.2;
  text-shadow:0 1px 8px rgba(0,0,0,.55);
}
'''
html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>Isolated selector reproduction</title><style>
body{font:16px/1.5 Arial,sans-serif;background:#f5f5f5;color:#222;margin:28px}
h1{font-size:21px}section,dialog{padding:22px;border:1px solid #ccc;border-radius:8px;background:white;margin:16px 0}
#local-font-dialog{position:static;width:auto} .samples{display:flex;align-items:flex-start;gap:70px} .sample{min-width:180px} small{display:block;color:#555;margin-top:12px}
</style><style>'''+old_local+shared+'''</style><h1>隔离 CSS 复现：共享样式的 DOM 作用范围</h1><p>此页不是拾光正式界面；只验证当前源码中的选择器与样式继承。</p>
<section id="detail-dialog" data-face-theme="classic" data-face-theme-effective="classic" style='--face-font-size:13px;--face-font-family:serif;--face-text-color:#f6f1e6;--face-bg-rgba:rgba(20,24,18,.5);--face-radius:10px;--face-padding-y:5px;--face-padding-x:3px;--face-shadow:0 1px 10px rgba(0,0,0,.65)'>
<div class="samples"><div class="sample"><p>实图标签结构</p><button class="face-name" style="position:relative">陈宁</button><small id="live-metric"></small></div><div class="sample"><p>主样式面板预览结构</p><span id="face-style-preview-label">陈宁</span><small id="preview-metric"></small></div></div></section>
<dialog id="local-font-dialog" open><p>本机字体弹窗：由 viewer.js 直接 append 到 body</p><span id="local-font-preview-label">陈宁</span><small id="local-metric"></small></dialog></html>'''
(ROOT/'selector_reproduction.html').write_text(html,encoding='utf-8')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1100,'height':700})
 page.set_content(html)
 def measure():
  return page.evaluate('''() => Object.fromEntries(['.face-name','#face-style-preview-label','#local-font-preview-label'].map(sel=>{const e=document.querySelector(sel),s=getComputedStyle(e);return [sel,{fontSize:s.fontSize,writingMode:s.writingMode,padding:s.padding,background:s.backgroundColor,localSharedSelector:e.matches('#detail-dialog #local-font-preview-label'),color:s.color,borderRadius:s.borderRadius,fontFamily:s.fontFamily}]}))''')
 data={'scope':'isolated DOM and verbatim relevant CSS rules, not a full app or production audit','commit':'9ba5fe6952642c782d69beeef99fb696a46bb8c7','browser':b.version,'classic':measure()}
 page.evaluate('''() => {for(const [sel,id] of [['.face-name','live-metric'],['#face-style-preview-label','preview-metric'],['#local-font-preview-label','local-metric']]){const s=getComputedStyle(document.querySelector(sel));document.getElementById(id).textContent=s.fontSize+' / '+s.writingMode;}}''')
 page.screenshot(path=str(ROOT/'local_font_selector.png'))
 # Match applyFaceStyle(tea) variable assignment, then the resource failure callback
 # sets only data-face-theme-effective=classic; it does not apply classic variables.
 page.evaluate('''() => {const e=document.querySelector('#detail-dialog');e.dataset.faceTheme='tea';e.dataset.faceThemeEffective='classic';for(const [k,v] of Object.entries({'--face-font-size':'16px','--face-font-family':'"Ma Shan Zheng",serif','--face-text-color':'#f7ead8','--face-bg-rgba':'rgba(126,98,75,.66)','--face-bg-opacity':'.66','--face-radius':'0px','--face-padding-x':'0px','--face-padding-y':'0px','--face-shadow':'none'})){e.style.setProperty(k,v)}}''')
 data['tea_missing_plate_effective_classic']=measure()
 data['assertions']=[
 {'id':'main_preview_matches_live_font_size','expected':True,'actual':data['classic']['.face-name']['fontSize']==data['classic']['#face-style-preview-label']['fontSize']},
 {'id':'local_font_preview_receives_shared_style','expected':True,'actual':data['classic']['#local-font-preview-label']['localSharedSelector']},
 {'id':'local_font_preview_is_vertical_for_Chinese','expected':'vertical-rl','actual':data['classic']['#local-font-preview-label']['writingMode']},
 {'id':'effective_classic_fallback_uses_classic_background','expected':data['classic']['.face-name']['background'],'actual':data['tea_missing_plate_effective_classic']['.face-name']['background']}
 ]
 for a in data['assertions']:a['status']='PASS' if a['actual']==a['expected'] else 'FAIL'
 (ROOT/'css-results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(data,ensure_ascii=False,indent=2))
 b.close()
